source /home/cs231n/myVE35/bin/activate
jupyter-notebook --no-browser --port=7000 &
