source .env/bin/activate
jupyter-notebook --no-browser --port=7000 &
